(* ::Package:: *)

(***************************************************************************************************************)
	(******                              GrIP modelfile for the Georgi Glashow Model                                 ******)
	(******                                                                                                        ******)
	(******          Authors: Upalaparna Banerjee, Joydeep Chakrabortty, Suraj Prakash, Shakeel Ur Rahaman      ******)
	(******                                                                                                        ******)
	(******                       Institutes: Indian Institute of Technology Kanpur, India                         ******)
	(***************************************************************************************************************)


(* ::Section:: *)
(*Information about the Model and Authors*)


(*    Set the version number    *)
GrIP`$GrIPVersion = "V.1.0.0";


(* ::Input::Initialization:: *)
CellPrint[
{Cell[DisplayForm["    GrIP-"<>ToString[GrIP`$GrIPVersion]],"Text",
CellFrame->True,Editable->False,FontFamily->"Lucida Calligraphy",
TextAlignment->Left,FontSize->18],
Cell[
DisplayForm[
"Model Name: Georgi-Glashow SU(5) Grand Unified Model \n
Authors: Upalaparna Banerjee, Joydeep Chakrabortty, Suraj Prakash, Shakeel Ur Rahaman \n 
Institutes: Indian Institute of Technology Kanpur, India \n
Emails: upalab, joydeep, surajprk, shakel@iitk.ac.in"],
"Text",CellFrame->True,FontFamily->"Lucida Calligraphy",Editable->False,
Background->White]}];


ModelName="GeorgiGlashowGUT";


(* ::Section:: *)
(*User Input : Symmetry Groups*)


(* ::Input::Initialization:: *)
SymmetryGroupClass={
Group[1]={"GroupName"-> "SU5",
			"N"-> 5
}
};



(* ::Section:: *)
(*User Input : Fields and their properties*)


FieldClass={
Field[1]={
		"FieldName"-> \[CapitalPhi],
		"Self-Conjugate"-> True,
		"Lorentz Behaviour"-> "SCALAR",
		"Chirality"-> "NA",
		"Baryon Number"-> 0,
		"Lepton Number"-> 0,
		"SU5Dyn"-> {1,0,0,1}
		},
Field[2]={
		"FieldName"-> \[CurlyPhi],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "SCALAR",
		"Chirality"-> "NA",
		"Baryon Number"-> 0,
		"Lepton Number"-> 0,
		"SU5Dyn"-> {1,0,0,0}
		},
Field[3]={
		"FieldName"-> \[Psi],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "l",
		"Baryon Number"-> 0,
		"Lepton Number"-> 0,
		"SU5Dyn"-> {0,0,0,1}
		},
Field[5]={
		"FieldName"-> \[Chi],
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "FERMION",
		"Chirality"-> "l",
		"Baryon Number"-> 0,
		"Lepton Number"-> 0,
		"SU5Dyn"-> {0,1,0,0}
		}
};




(* ::Section:: *)
(*User Input : Gauge Field tensors and their properties*)


FieldTensorClass={
TensorField[1]={
		"FieldName"-> Al,
		"Self-Conjugate"-> False,
		"Lorentz Behaviour"-> "VECTOR",
		"Chirality"-> "l",
		"Baryon Number"-> 0,
		"Lepton Number"-> 0,
		"SU5Dyn"-> {1,0,0,1}
		}
};
